﻿using _2024_09_19.klasy;

namespace _2024_09_19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string kontynuacja = "t";
            while (kontynuacja == "t")
            {
                Kosci gra = new Kosci();
                int kostki = 0;
                while (kostki > 10 || kostki < 3)
                {
                    Console.WriteLine("Ile kostek chcesz rzucić?(3 - 10)");
                    kostki = Int32.Parse(Console.ReadLine());
                }

                int[] wartosci = gra.losowanie(kostki);
                gra.liczenie_punktów(wartosci);

                Console.WriteLine("Jeszcze raz? (t/n)");
                kontynuacja = Console.ReadLine();

                if (kontynuacja == "n")
                {
                    break;
                }
            }
        }
    }
}

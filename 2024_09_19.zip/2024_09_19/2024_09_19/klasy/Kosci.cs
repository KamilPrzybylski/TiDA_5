﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2024_09_19.klasy
{
    internal class Kosci
    {
        /*
         ***************************
            nazwa:              losowanie()
            opis:               funkcja losująca liczbę oczek na kostkach (liczba kostek określona parametrem kostki),
                                oraz wyświetla te wartości wg. wzoru: "Kostka <numer_kostki>: <liczba oczek>"
            parametry:          kostki:
                                    typ: int (liczba całkowita)
                                    opis: liczba kostek do losowania
            zwracany typ i opis:zwraca tablicę liczb całkowitych "rzucone_oczka"
            autor:              06242803856
         ***************************
         */
        public int[] losowanie(int kostki)
        {
            int[] rzucone_oczka = new int[kostki];
            for (int i = 1; i <= kostki; i++)
            {
                Random generator = new Random();
                int los = generator.Next(1, 7);
                rzucone_oczka[i - 1] = los;
                Console.WriteLine("Kostka " + i + ": " + los);
            }
            return rzucone_oczka;
        }

        /*
         ***************************
            nazwa:              liczenie_punktow()
            opis:               funkcja przelicza liczbę punktów według wzoru podanego w poleceniu oraz ją wyświetla
            parametry:          wartosci:
                                    typ: int[] (tablica liczb całkowitych)
                                    opis: wartości oczek niezbędne do przeliczenia punktów
            zwracany typ i opis:brak
            autor:              06242803856
         ***************************
         */
        public void liczenie_punktów(int[] wartosci)
        {
            int punkty = 0;

            for (int i = 0; i < wartosci.Length; i++)
            {
                int powt = 0;
                for (int j = 0; j < wartosci.Length; j++)
                {
                    if (wartosci[i] == wartosci[j])
                    {
                        powt++;
                    }
                }
                if (powt > 1)
                {
                    punkty = punkty + wartosci[i];
                }
            }
            Console.WriteLine("Liczba uzyskanych punktów: " + punkty);
        }
    }
}

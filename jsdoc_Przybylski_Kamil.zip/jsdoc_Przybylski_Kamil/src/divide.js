/**
 * Wykonuje działanie dzielenia liczby a (licznika) przez liczbę b (mianownik) i zwraca wynik
 * @param {number} a Licznik
 * @param {number} b Mianownik
 * @throws {Error} Jeżeli mianownik jest równa 0
 * @returns {number} Wynik dzielenia
 * @example
 * const x = 10
 * const y = 2
 *
 * const result = divide(x,y)
 * console.log(result)
 *
 * // Logs: 5
 * @author Kamil Przybylski 5D
 */

function divide(a,b) {
    if (b === 0) {
        throw new Error('Nie dziel przez 0')
    }
    else {
        return a/b
    }
}
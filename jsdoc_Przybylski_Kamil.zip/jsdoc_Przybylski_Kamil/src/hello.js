/**
 * Wyświetla alert witający
 * @param {string} somebody Np: imię osoby, którą chcemy powitać
 * @returns None (`undefined`)
 * @author Kamil Przybylski 5D
 */
const sayHello = (somebody) => {
    alert(`Hello ${somebody}`);
}
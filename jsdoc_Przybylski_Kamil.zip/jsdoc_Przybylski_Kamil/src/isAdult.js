/**
 * Sprawdza czy osoba jest pełnoletnia
 * @param {number} age Wiek osoby
 * @throws {Error} Jeżeli wiek nie jest większy od 0
 * @returns {boolean} `true` jeżeli jest pełnoletnia lub `false` jeżeli nie
 * @author Kamil Przybylski 5D
 */
function isAdult(age){
    if (age <= 0){
        throw new Error("Wiek musi być większy od 0");
    }
    else if (age >= 18) {
        return true
    }
    else {
        return false
    }
}
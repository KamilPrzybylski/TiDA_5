/**
 * Oblicza pole koła o podanym promieniu
 * @param {number} radius Promień
 * @throws {Error} Jeżeli promień koła nie jest dodatni
 * @returns {number} Pole koła
 * @author Kamil Przybylski 5D
 */
function circleArea(radius){
    if (radius <= 0) {
        throw new Error("Promień musi być dodatni");
    }
    else {
        return Math.PI * radius * radius
    }
}